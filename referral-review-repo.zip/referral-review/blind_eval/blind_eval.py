"""Blind evaluation: the model sees the criteria and one packet's OCR text, never the decisions.

  pip install anthropic
  export ANTHROPIC_API_KEY=...
  python blind_eval.py suggest        # writes suggestions/R01.json ... (no labels loaded)
  python blind_eval.py score          # only now reads decisions.json and compares

Keep decisions.json out of reach until you run `score`. Criteria come from the repo's criteria/ folder (or CRITERIA_DIR).
"""
import json, os, sys, glob, re
import anthropic

MODEL = os.environ.get("MODEL", "claude-sonnet-5-5")
HERE = os.path.dirname(os.path.abspath(__file__))
client = anthropic.Anthropic()

def find_dir(env, *cands):
    for c in ([os.environ.get(env)] if os.environ.get(env) else []) + [os.path.join(HERE, x) for x in cands]:
        if c and os.path.isdir(c): return os.path.abspath(c)
    sys.exit(f"Cannot find {cands[0]}. Set {env}.")

CRIT = find_dir("CRITERIA_DIR", "criteria", "../criteria", "../../criteria", "../../../criteria")

def read(p): return open(os.path.join(CRIT, p), encoding="utf-8").read()

SYSTEM = """You help a recuperative-care referral coordinator. Apply the criteria below to one referral packet.
Rules:
- The packet is OCR text of faxed scans. It is noisy. Quote only what you can read.
- Not in the packet means unknown, not normal. Mark it missing or unclear.
- The internal admission criteria win over the referral form. Where they are silent, the form's exclusions apply.
- Use the children's criteria only if the patient is under 18.
- Never decide on a single coded diagnosis without saying so.
- Output JSON only: {"suggestion":"approve|deny|hold","reason":"one sentence",
 "rules":[{"rule":"...","status":"fails|unclear|meets|missing","evidence":"...","page":N}],
 "contradictions":["..."],"ask_hospital":["..."]}
- page is the page number from the === PAGE n === markers.

ADMISSION CRITERIA
""" + read("admission-criteria.md") + "\n\nREFERRAL FORM RULES\n" + read("referral-form-and-checklist.md") + "\n\nCHILDREN'S CRITERIA\n" + read("childrens-admission-criteria.md")

def packet_text(pid):
    pages = sorted(glob.glob(os.path.join(HERE, "packets_text", f"{pid}_p-*.txt")),
                   key=lambda f: int(re.search(r"-(\d+)\.txt", f).group(1)))
    return "\n".join(f"=== PAGE {i+1} ===\n{open(f, encoding='utf-8', errors='ignore').read()}" for i, f in enumerate(pages))

def suggest():
    os.makedirs(os.path.join(HERE, "suggestions"), exist_ok=True)
    ids = sorted({re.match(r"(R\d+)_", os.path.basename(f)).group(1) for f in glob.glob(os.path.join(HERE, "packets_text", "*.txt"))})
    for pid in ids:
        out = os.path.join(HERE, "suggestions", f"{pid}.json")
        if os.path.exists(out): continue
        r = client.messages.create(model=MODEL, max_tokens=4000, system=SYSTEM,
            messages=[{"role": "user", "content": f"Packet {pid}:\n\n{packet_text(pid)}"}])
        text = r.content[0].text.strip().removeprefix("```json").removesuffix("```").strip()
        json.dump(json.loads(text), open(out, "w"), indent=1)
        print(pid, json.loads(text)["suggestion"])

def score():
    dec = os.environ.get("DECISIONS") or next((p for p in [os.path.join(HERE, "decisions.json"), os.path.join(HERE, "../../eval/decisions.json"), os.path.join(HERE, "../eval/decisions.json")] if os.path.exists(p)), None)
    if not dec: sys.exit("Set DECISIONS=path/to/decisions.json (only now, after suggest has finished).")
    truth = {p["packet_id"]: p["decision"] for p in json.load(open(dec))["packets"]}
    rows, agree = [], 0
    for f in sorted(glob.glob(os.path.join(HERE, "suggestions", "R*.json"))):
        pid = os.path.basename(f)[:-5]; s = json.load(open(f))
        ok = s["suggestion"] == truth[pid]; agree += ok
        rows.append((pid, s["suggestion"], truth[pid], "match" if ok else "REVIEW", s["reason"]))
    for r in rows: print(" | ".join(r))
    print(f"\nexact agreement: {agree}/{len(rows)}")
    print("A hold is not a miss: it means the packet could not settle the question. Review every REVIEW row by hand;")
    print("IHH recorded no reasons, so a mismatch may be the rules or IHH's judgment.")

if __name__ == "__main__":
    {"suggest": suggest, "score": score}[sys.argv[1]]()
