# Referral review desk

Team code for Challenge 1 (referral intake).

- `referral-review.html`: single-file review page. Open it in a browser. For each packet it shows a suggestion, rule-by-rule evidence with sources, form-versus-chart contradictions, and a draft reply. Approve and deny stay locked until a coordinator ticks every flagged item as checked against the original page. Nothing is sent.
- `blind_eval/blind_eval.py`: scores the suggestions without the model ever seeing IHH's decisions.

## Before you commit
The page embeds short summaries of what each packet contains (ages, diagnoses, clinical details, page references). They are de-identified, but they are derived from the packets. Ask an organizer whether that is acceptable before this goes in a shared repo. If not, delete the `P` data block in the page's script and load it from a gitignored file.

## Blind evaluation
1. Put OCR text of each packet in `blind_eval/packets_text/` as `R01_p-01.txt`, `R01_p-02.txt`, and so on (gitignored). Generate it locally from the PDFs you downloaded, for example with `pdftoppm -r 130 -gray -png` then `tesseract`.
2. `pip install anthropic`, set `ANTHROPIC_API_KEY`.
3. `python blind_eval/blind_eval.py suggest` (reads `criteria/` from the repo, never loads decisions).
4. `DECISIONS=eval/decisions.json python blind_eval/blind_eval.py score`.

A hold against an approve is not necessarily an error. Review every REVIEW row by hand; IHH recorded no reasons.
